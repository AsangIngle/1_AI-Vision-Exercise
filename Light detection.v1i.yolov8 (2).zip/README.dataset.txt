# Light detection > 2025-07-30 3:29pm
https://universe.roboflow.com/accident-w844b/light-detection-meyrn

Provided by a Roboflow user
License: CC BY 4.0

